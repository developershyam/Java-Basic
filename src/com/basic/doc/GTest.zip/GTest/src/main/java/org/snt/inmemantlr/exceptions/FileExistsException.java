package org.snt.inmemantlr.exceptions;

public class FileExistsException extends Exception {

    FileExistsException(String msg) {
        super(msg);
    }
}
