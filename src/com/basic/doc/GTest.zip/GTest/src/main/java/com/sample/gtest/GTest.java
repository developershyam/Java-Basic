package com.sample.gtest;

import java.io.File;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.snt.inmemantlr.GenericParser;
import org.snt.inmemantlr.listener.DefaultListener;
import org.snt.inmemantlr.listener.DefaultTreeListener;
import org.snt.inmemantlr.tree.ParseTree;
import org.snt.inmemantlr.utils.FileUtils;
import org.antlr.v4.runtime.*;

public class GTest {

	public static void main(String[] args) throws Exception {

		// 1. load grammar
		//File f = new File("D:\\test-app\\Java.g4.txt");
		File f = new File("D:\\test-app\\ANTLRv4Parser.g4.txt");
		GenericParser gp = new GenericParser(f);
		
		// 2. load file content into string
		//String s = FileUtils.loadFileContent("HelloWorld.java");
		//String s = "1. My name is Shyam Pareek.";
		// 3. set listener for checking parse tree elements. Here you could use any
		// ParseTreeListener implementation. The default listener is used per default
		//gp.setListener(new DefaultListener());
		// 4. compile Lexer and parser in-memory
		//gp.compile();
		// 5. parse the string that represents the content of HelloWorld.java
		//ParserRuleContext ctx = gp.parse(s);
		
		
		
		String s = "class A { private int i =5; int j =10;}";
		// this listener will create a parse tree from the java file
		DefaultTreeListener dlist = new DefaultTreeListener();

		gp.setListener(dlist);
		gp.compile();

		ParserRuleContext ctx = gp.parse(s);

		// get access to the parse tree of inmemantlr
		ParseTree pt = dlist.getParseTree();
		
		String json = pt.toJson();
		
		System.out.println("-----"+json);
		
		System.out.println(tokenize("Hi this is Shyam. I work on Java.", "en", "US"));
	}
	
	public static List<String> tokenize(String text, String language, String country){
	    List<String> sentences = new ArrayList<String>();
	    Locale currentLocale = new Locale(language, country);
	    BreakIterator sentenceIterator = BreakIterator.getSentenceInstance(currentLocale);      
	    sentenceIterator.setText(text);
	    int boundary = sentenceIterator.first();
	    int lastBoundary = 0;
	    while (boundary != BreakIterator.DONE) {
	        boundary = sentenceIterator.next();         
	        if(boundary != BreakIterator.DONE){
	            sentences.add(text.substring(lastBoundary, boundary));
	        }
	        lastBoundary = boundary;            
	    }
	    return sentences;
	}
}
